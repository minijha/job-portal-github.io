 
	<section id="content">
	
	<div class="container">
		<div class="row"> 
							<div class="col-md-12">
								<div class="about-logo">
									<h3>Voluptatem Accusantium Doloremque</h3>
									<p>Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas</p>
                                    	<p>Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas</p>
								</div>  
							</div>
						</div>
	<div class="row">
								<div class="col-md-7">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do tempor.</p>
		 <a href="https://api.whatsapp.com/send/?phone=9999999999&text&app_absent=0">
	    <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-comment" aria-hidden="true"> What's App  </i> </button></a><br />
		<br /><br />
		<a href="mailto:jugaad1215@gmail.com">
	    <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-envelope" aria-hidden="true">&nbsp &nbsp E-Mail &nbsp &nbsp </i> </button></a>
          
		
								</div>
								
				
	</div>

 
	</section>
 